function displayvals(){
    var singlevalue=$("single value").val();
    var multiplevalue=$("multiple").val();
    $("p").html("<b>single</b>"+singlevalue+"<b>multiplevalue</b>"+multiplevalue.join(","));
}
$("select").on("change",displayvals);
displayvals();