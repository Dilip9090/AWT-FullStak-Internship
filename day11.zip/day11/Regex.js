const regex=/catholic/g;
const str1="nory not catholic"
document.write("<hr/><br/>",str1.replace(regex,"hindu"))

var regex1=/nory/i;
var output=regex.exec(str1);
document.write("<br/>",output);
console.log(output);

var matchcase=regex.test(str1);
document.write("<br/>",matchcase)

let txt="What What is IS up 6345678!"
let result=txt.match(/[a-z,0-9]/gi);
document.write("<br/>",result);