// document.write("<br/"+Number("3.1478"));
// document.write("<br/"+Number(""));
// document.write("<br/"+Number(""));
// document.write("<br/"+Number("99 88"));

let munexp = 3.14;
document.write("<br/>"+munexp.toExponential(1));
document.write("<br/>"+munexp.toExponential(2));
document.write("<br/>"+munexp.toExponential(3));
document.write("<br/>"+munexp.toExponential(4));

let numfixed=3.14
document.write("<br/>"+numfixed.toFixed());
document.write("<br/>"+numfixed.toFixed(2));
document.write("<br/>"+numfixed.toFixed(3));
document.write("<br/>"+numfixed.toFixed(4));

let numpre=3.14;
document.write("<br>"+numpre.toPrecision());
document.write("<br>"+numpre.toPrecision(2));
document.write("<br>"+numpre.toPrecision(3));
document.write("<br>"+numpre.toPrecision(4));

document.write("<br/>"+new Date());
document.write("<br/>"+new Date("2023-06-28"));
document.write("<br/>"+new Date(2023,05,11,23,0));
document.write("<br/>"+new Date("june 28,2023"));