function demoonclick(){
    alert("onclick");
}

function demoondbclick(){
    alert("ondoubleclick");
}

function demoOnFocus(){
    document.getElementById("txtFocus").style.backgroundColor="blue";
}

function demoOnBlur(){
    document.getElementById("txtBlur").style.backgroundColor="yellow";
}

function demoonkeypress(){
    alert(keypress);
}

function demoOnkeyup(){
    alert("keyup Done");
}