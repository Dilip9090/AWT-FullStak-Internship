var a=["Manav","Dawawala"]

document.write(a instanceof Array);
document.write("<br/>");
document.write(a instanceof Number);

document.write("<br/>");

